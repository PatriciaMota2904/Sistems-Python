from models.produto import Produto

ps4 = Produto('Playstation 4', 1789.49)
xbox = Produto('Xbox 360', 1699.45)

print(ps4)
print(xbox)
